﻿using System;
using System.IO;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;

namespace SanitizeMe.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            RegistryKey key = Registry.LocalMachine.OpenSubKey
                  (@"HKEY_LOCAL_MACHINE\\SOFTWARE\\RTT AG\\POS", RegistryKeyPermissionCheck.ReadWriteSubTree);
            bool val = (bool)key.GetValue("secMktExpertMode", true);
            //string str = "https://man-test.rendercloud.solution-server.com/api/Render/DownloadPreAuthorisedContent?id=v7C2s%2fU6OX8BwfnCkzonztqYjco4wDjwrXeFplrd3KQcoF%2bJyWgj2iG937vcSnO2RGIzrLjWuDcGUqWM39xsYQ%3d%3d";
            string str = "e92e1a66-793a-435a-93cf-5aca10efab68";
           string decoded=System.Uri.UnescapeDataString(str);
            // mybytearray = Convert.FromBase64String(str).ToString();

        }
    }
}
