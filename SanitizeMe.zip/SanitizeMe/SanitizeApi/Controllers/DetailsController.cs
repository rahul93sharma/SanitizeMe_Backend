﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Xml;
using MySql.Data.MySqlClient;

namespace SanitizeApi.Controllers
{
    public class DetailsController : ApiController
    {
        static readonly object _object = new object();

        [HttpPost]
        [Route("api/api/CustomerDetails")]
        public string ReturnXmlDocument([FromBody] CustomerDetails customerDetails)
        {
            try
            {
                lock (_object)
                {
                    MySqlConnection con = sqlconnection();
                    con.Open();
                    var cmd = new MySqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "INSERT INTO CustomerDetails(Name, ContactNumber,Email,Address,ServiceSelected,VehicleServiceSelected,AtShowroom)" +
                                     " VALUES('" + customerDetails.Name + "','" +"91"+
                                     customerDetails.ContactNumber + "','"
                                     + customerDetails.Email + "','" + customerDetails.Address.Replace("'","") + "','" + customerDetails.ServiceSelected + "','" + DateTime.Now.AddHours(5.5) + "','" + customerDetails.AtShowroom + "')";
                    cmd.ExecuteNonQuery();
                    con.Close();

                    return "success";

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
        public class ActivateMessageService
        {
            public string ActivateMessage;
           
        }
        public class CustomerDetails
        {
            public string Name;
            public string Address;
            public string ContactNumber;
            public string Email;
            public string ServiceSelected;
            public string VehicleServiceSelected;
            public string AtShowroom;
        }
        public class CityDetails
        {
            public string City;

        }
        public class CityList
        {
            public List<string> CityNames { get; set; }
        }

        public class ShowroomDetails
        {
            public List<ShowroomDetailsApi> Details { get; set; }

        }

        public class ShowroomDetailsApi
        {
            public string ShowroomContact { get; set; }
            public string ShowroomAddress { get; set; }
        }

        [HttpPost]
        [Route("api/Showroomdetails")]
        public ShowroomDetails GetAgencyDetails([FromBody] CityDetails cityDetails)
        {
            var result = new ShowroomDetails();
            try
            {
                string ShowroomContact = string.Empty;
                string ShowroomAddress = string.Empty;
                MySqlConnection con = sqlconnection();
                con.Open();
                 var queryContactDetail = "SELECT ShowroomContact,ShowroomAddress from AgencyContactDetails where City = '" + cityDetails.City + "'";
                 var cmd = new MySqlCommand(queryContactDetail, con);
                MySqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        ShowroomContact = reader.GetString(1);
                        ShowroomAddress = reader.GetString(0);
                    }
                }
                else
                {
                    string msg="no showroom for the selected city";
                    return result = null;
                }
                con.Close();
                result.Details = new List<ShowroomDetailsApi>();
                var detail = new ShowroomDetailsApi();
                detail.ShowroomContact = ShowroomContact;
                detail.ShowroomAddress = ShowroomAddress;
                result.Details.Add(detail);
                return result;
            }
            catch (Exception ex)
            {
                return result = null;
            }
        }

        public class BookingDetails
        {
            public List<BookingDetailsApi> Details { get; set; }

        }

        public class BookingDetailsApi
        {
            public string BookingId { get; set; }
            public string Name { get; set; }
            public string ContactNumber { get; set; }
            public string Email { get; set; }
            public string Address { get; set; }
            public string ServiceSelected { get; set; }
            public string VehicleServiceSelected { get; set; }
            public string AtShowroom { get; set; }
        }


        [HttpGet]
        [Route("api/BookingDetails")]
        public BookingDetails GetBookingDetails()
        {
            var result = new BookingDetails();
            try
            {
                string BookingId = string.Empty;
                string Name = string.Empty;
                string ContactNumber = string.Empty;
                string Email = string.Empty;
                string Address = string.Empty;
                string ServiceSelected = string.Empty;
                string VehicleServiceSelected = string.Empty;
                string AtShowroom = string.Empty;
               
                MySqlConnection con = sqlconnection();
                con.Open();
                var queryContactDetail = "SELECT BookingId,Name,ContactNumber,Email,Address,ServiceSelected,VehicleServiceSelected,AtShowroom from CustomerDetails";
                var cmd = new MySqlCommand(queryContactDetail, con);
                MySqlDataReader reader = cmd.ExecuteReader();
                var detail = new BookingDetailsApi();
                result.Details = new List<BookingDetailsApi>();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        BookingId = reader.GetString(0);
                        Name = reader.GetString(1);
                        ContactNumber = reader.GetString(2);
                        Email = reader.GetString(3);
                        Address = reader.GetString(4);
                        ServiceSelected = reader.GetString(5);
                        VehicleServiceSelected = reader.GetString(6);
                        AtShowroom = reader.GetString(7);

                        detail = new BookingDetailsApi();
                        detail.BookingId = BookingId;
                        detail.Name = Name;
                        detail.ContactNumber = ContactNumber;
                        detail.Email = Email;
                        detail.Address = Address;
                        detail.ServiceSelected = ServiceSelected;
                        detail.VehicleServiceSelected = VehicleServiceSelected;
                        detail.AtShowroom = AtShowroom;
                        result.Details.Add(detail);
                    }
                }
                else
                {
                    string msg = "no bookings";
                    return result = null;
                }
                con.Close();
                return result;
            }
            catch (Exception ex)
            {
                return result = null;
            }
        }


        [HttpGet]
        [Route("api/BookingDetailsExpired")]
        public BookingDetails GetBookingDetailsExpired()
        {
            var result = new BookingDetails();
            try
            {
                string BookingId = string.Empty;
                string Name = string.Empty;
                string ContactNumber = string.Empty;
                string Email = string.Empty;
                string Address = string.Empty;
                string ServiceSelected = string.Empty;
                string VehicleServiceSelected = string.Empty;
                string AtShowroom = string.Empty;

                MySqlConnection con = sqlconnection();
                con.Open();
                var queryContactDetail = "SELECT BookingId,Name,ContactNumber,Email,Address,ServiceSelected,VehicleServiceSelected,AtShowroom from CustomerDetailsExpired";
                var cmd = new MySqlCommand(queryContactDetail, con);
                MySqlDataReader reader = cmd.ExecuteReader();
                var detail = new BookingDetailsApi();
                result.Details = new List<BookingDetailsApi>();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        BookingId = reader.GetString(0);
                        Name = reader.GetString(1);
                        ContactNumber = reader.GetString(2);
                        Email = reader.GetString(3);
                        Address = reader.GetString(4);
                        ServiceSelected = reader.GetString(5);
                        VehicleServiceSelected = reader.GetString(6);
                        AtShowroom = reader.GetString(6);

                        detail = new BookingDetailsApi();
                        detail.BookingId = BookingId;
                        detail.Name = Name;
                        detail.ContactNumber = ContactNumber;
                        detail.Email = Email;
                        detail.Address = Address;
                        detail.ServiceSelected = ServiceSelected;
                        detail.VehicleServiceSelected = VehicleServiceSelected;
                        detail.AtShowroom = AtShowroom;
                        result.Details.Add(detail);
                    }
                }
                else
                {
                    string msg = "no bookings";
                    return result = null;
                }
                con.Close();
                return result;
            }
            catch (Exception ex)
            {
                return result = null;
            }
        }

        public string GetValueformDatabase(string query, MySqlConnection con)
        {
            var SelectQuery = query;
            var cmd = new MySqlCommand(SelectQuery, con);
            string datavalue = cmd.ExecuteScalar().ToString();
            return datavalue;
        }

        public MySqlConnection sqlconnection()
        {
            MySqlConnection connection;
            //prod
            string server = "EC2AMAZ-4FLQNIN";
            string database = "SanitizeMe";
            string uid = "root";
            string password = "1234";
            //testing
            //string server = "pun-rahulsh01";
            //string database = "sys";
            //string uid = "root";
            //string password = "1234";
            //string connectionString = ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString;
            string connectionString;
            connectionString = "SERVER=" + server + ";" + "DATABASE=" +
            database + ";" + "UID=" + uid + ";" + "PASSWORD=" + password + ";";

            connection = new MySqlConnection(connectionString);
            return connection;
        }

        [HttpGet]
        [Route("api/testing")]
        public string GetTestAPI()
        {
            return "Success";
        }
        [HttpGet]
        [Route("api/ActivateMessageService")]
        public ActivateMessageService GetActivateMessage()
        {
            var result = new ActivateMessageService();
            try
            {
                MySqlConnection con = sqlconnection();
                con.Open();
                var activateMessageService = "SELECT * from ActivateMessageService";
                string activateMessage = GetValueformDatabase(activateMessageService, con);
                con.Close();
                result.ActivateMessage = activateMessage;
                
                return result;
            }
            catch (Exception ex)
            {
                return result = null;
            }
        }

        [HttpGet]
        [Route("api/CityNames")]
        public CityList GetCityList()
        {
            var result = new CityList();
            try
            {
                List<string> cityNamesList = new List<string>();
                MySqlConnection con = sqlconnection();
                con.Open();
                var cityList = "SELECT City from AgencyContactDetails";
                var cmd = new MySqlCommand(cityList, con);
                MySqlDataReader reader;
                reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        string citynames = reader["City"].ToString();
                        cityNamesList.Add(reader.GetString(0));
                    }
                }
                else
                {
                    string msg = "No Showrooms";
                    cityNamesList.Add(msg);
                }
                reader.Close();
                con.Close();
                result.CityNames = cityNamesList;

                return result;
            }
            catch (Exception ex)
            {
                return result = null;
            }
        }
    }
}
